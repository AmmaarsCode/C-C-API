#include <cpprest/http_client.h>
#include <cpprest/filestream.h>
#include <iostream>

using namespace utility;                    // Common utilities like string conversions
using namespace web;                        // Common features like URIs.
using namespace web::http;                  // Common HTTP functionality
using namespace web::http::client;          // HTTP client features
using namespace concurrency::streams;       // Asynchronous streams

int main(int argc, char* argv[])
{
    // Prompt the user for their API key and ID
    std::string api_key;
    std::string api_id;
    std::cout << "Please enter your API key: ";
    std::cin >> api_key;
    std::cout << "Please enter your API ID: ";
    std::cin >> api_id;

    // Construct the API URL
    std::string api_url = "https://canvas.instructure.com/api/v1/courses/" + api_id + "/assignments?access_token=" + api_key;

    // Make the API call
    http_client client(api_url);
    pplx::task<http_response> response = client.request(methods::GET);
    http_response api_response = response.get();

    // Parse the response data
    json::value json_data = api_response.extract_json().get();
    auto assignments = json_data.as_array();

    // Iterate through the assignments and print the name and due date
    for (auto &assignment : assignments)
    {
        std::string name = assignment["name"].as_string();
        std::string due_date = assignment["due_at"].as_string();
        std::cout << name << " - Due on " << due_date << std::endl;
    }

    return 0;
}
